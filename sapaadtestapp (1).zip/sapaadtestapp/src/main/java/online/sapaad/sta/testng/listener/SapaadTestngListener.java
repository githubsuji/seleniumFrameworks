package online.sapaad.sta.testng.listener;

public class SapaadTestngListener extends TestCaseMethodListener {

}
