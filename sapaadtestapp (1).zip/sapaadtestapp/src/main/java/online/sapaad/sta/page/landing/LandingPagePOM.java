package online.sapaad.sta.page.landing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class LandingPagePOM {
	private WebDriver driver;

	@FindBy(how = How.ID, using = "login")
	private WebElement signInOrRegisterBtn;

	@FindBy(how = How.CSS, using = "#phone")
	private WebElement emailOrMobileTxtF;

	private WebElement signInContinueBtn;

	private WebElement emailIdDisplayed;

	private WebElement signPageHeader;

	private WebElement passwordField;

	private WebElement signInBtn;

	private WebElement userDisplayLink;
	private WebElement signoutBtn;

	public LandingPagePOM(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}

	public LandingPagePOM(WebDriver driver, Boolean isReload) {
		{
			this.driver = driver;
			PageFactory.initElements(this.driver, this);
			signInContinueBtn = this.driver
					.findElement(By.xpath(LandingPageConstants.LOGIN_XPATH_SIGN_IN_CONTINUE_BTN));
			try {
				// Wait<WebDriver> wait = WaitManager.getFluentWait(this.driver, 100, 1000);
				// emailIdDisplayed=WaitManager.getElementByXpathAfterFWait(wait,
				// LandingPageConstants.LOGIN_XPATH_SIGN_IN_EMAIL_FIELD);
				emailIdDisplayed = this.driver
						.findElement(By.xpath(LandingPageConstants.LOGIN_XPATH_SIGN_IN_EMAIL_FIELD));
				signPageHeader = this.driver.findElement(By.xpath(LandingPageConstants.SIGNUP_XPATH_SIGNUP_HEADER));
				passwordField = this.driver
						.findElement(By.cssSelector(LandingPageConstants.LOGIN_CSS_SELECTOR_PASSWORD));
				signInBtn = this.driver.findElement(By.cssSelector(LandingPageConstants.LOGIN_CSS_SELECTOR_LOGIN));

			} catch (Exception e) {

			}
		}
	}

	public LandingPagePOM(Boolean relaod, WebDriver driver) {
		this.driver = driver;
		try {
			userDisplayLink = this.driver
					.findElement(By.partialLinkText(LandingPageConstants.LOGIN_PARTIAL_LINK_TEXT_USER_DISPLAY));
			signoutBtn = this.driver.findElement(By.xpath(LandingPageConstants.SIGNOUT_XPATH_BTN));
		} catch (Exception e2) {
			e2.printStackTrace();
		}

	}
	public LandingPagePOM(int relaod, WebDriver driver) {
		this.driver = driver;
		try {
			
			signoutBtn = this.driver.findElement(By.xpath(LandingPageConstants.SIGNOUT_XPATH_BTN));
		} catch (Exception e2) {
			e2.printStackTrace();
		}

	}

	public WebElement getSignInOrRegisterBtn() {
		return signInOrRegisterBtn;
	}

	public void setSignInOrRegisterBtn(WebElement signInOrRegisterBtn) {
		this.signInOrRegisterBtn = signInOrRegisterBtn;
	}

	public WebElement getEmailOrMobileTxtF() {
		return emailOrMobileTxtF;
	}

	public void setEmailOrMobileTxtF(WebElement emailOrMobileTxtF) {
		this.emailOrMobileTxtF = emailOrMobileTxtF;
	}

	public WebElement getSignInContinueBtn() {
		return signInContinueBtn;
	}

	public void setSignInContinueBtn(WebElement signInContinueBtn) {
		this.signInContinueBtn = signInContinueBtn;
	}

	public WebElement getEmailIdDisplayed() {
		return emailIdDisplayed;
	}

	public void setEmailIdDisplayed(WebElement emailIdDisplayed) {
		this.emailIdDisplayed = emailIdDisplayed;
	}

	public WebElement getSignPageHeader() {
		return signPageHeader;
	}

	public void setSignPageHeader(WebElement signPageHeader) {
		this.signPageHeader = signPageHeader;
	}

	public WebElement getPasswordField() {
		return passwordField;
	}

	public void setPasswordField(WebElement passwordField) {
		this.passwordField = passwordField;
	}

	public WebElement getSignInBtn() {
		return signInBtn;
	}

	public void setSignInBtn(WebElement signInBtn) {
		this.signInBtn = signInBtn;
	}

	public WebElement getUserDisplayLink() {
		return userDisplayLink;
	}

	public void setUserDisplayLink(WebElement userDisplayLink) {
		this.userDisplayLink = userDisplayLink;
	}

	public WebElement getSignoutBtn() {
		return signoutBtn;
	}

	public void setSignoutBtn(WebElement signoutBtn) {
		this.signoutBtn = signoutBtn;
	}

}
