package com.calibroz.driver;

public class WebElementConstants {
	public static final String ATTRIBUTE_INNER_HTML = "innerHTML";

}
