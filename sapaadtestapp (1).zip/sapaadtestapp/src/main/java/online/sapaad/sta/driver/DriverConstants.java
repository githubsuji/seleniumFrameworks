package online.sapaad.sta.driver;

public class DriverConstants {
	public static final String CHROME = "CHROME";
	public static final String FIREFOX = "FIREFOX";
	public static final String EDGE = "EDGE";
	public static final String IE = "IE";
	public static final String SAFARI = "SAFARI";

}
