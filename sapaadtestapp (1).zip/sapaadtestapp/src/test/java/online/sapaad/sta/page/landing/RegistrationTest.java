package online.sapaad.sta.page.landing;


import org.apache.log4j.Logger;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import online.sapaad.sta.driver.BaseTest;
import online.sapaad.sta.driver.WaitManager;
import online.sapaad.sta.page.landing.registration.RegistrationData;


public class RegistrationTest extends BaseTest {
	public final static Logger logger = Logger.getLogger(RegistrationTest.class);
	@BeforeMethod
	public void beforeEachTestCase() {
		WaitManager.applyJavaWait(3000);
		driver.get("http://43c0253d18b042a193f5784ca3382c52.sapaad-review.online/");
	}

	@Test(description = "Registration test", dataProvider = "registrationDataProvider", dataProviderClass = LandinpageDataProvider.class)
	public void registrationTest(RegistrationData data) throws InterruptedException {
		logger.info(data);
		LandingPageActions.inputUsernameAndContinue(driver, LandingPageUtil.createNewMailId(data.getEmailid()));
		LandingPageActions.inputRegistrationDataAndSubmit(driver, data);
		LandingPageActions.enterOtp(driver, data);
		
	}
	
}
