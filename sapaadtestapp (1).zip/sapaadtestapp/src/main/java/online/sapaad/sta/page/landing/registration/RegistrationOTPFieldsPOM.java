package online.sapaad.sta.page.landing.registration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class RegistrationOTPFieldsPOM {
	
	private WebDriver driver;

	@FindBy(how = How.ID, using = "otp_1")
	private WebElement otp1;
	
	@FindBy(how = How.ID, using = "otp_2")
	private WebElement otp2;

	@FindBy(how = How.ID, using = "otp_3")
	private WebElement otp3;
	
	@FindBy(how = How.ID, using = "otp_4")
	private WebElement otp4;
	
	@FindBy(how = How.ID, using = "confirm_continue")
	private WebElement confirmContinue;

	public RegistrationOTPFieldsPOM(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}

	public WebElement getOtp1() {
		return otp1;
	}

	public void setOtp1(WebElement otp1) {
		this.otp1 = otp1;
	}

	public WebElement getOtp2() {
		return otp2;
	}

	public void setOtp2(WebElement otp2) {
		this.otp2 = otp2;
	}

	public WebElement getOtp3() {
		return otp3;
	}

	public void setOtp3(WebElement otp3) {
		this.otp3 = otp3;
	}

	public WebElement getOtp4() {
		return otp4;
	}

	public void setOtp4(WebElement otp4) {
		this.otp4 = otp4;
	}

	public WebElement getConfirmContinue() {
		return confirmContinue;
	}

	public void setConfirmContinue(WebElement confirmContinue) {
		this.confirmContinue = confirmContinue;
	}
	
	
	
	
	

}
