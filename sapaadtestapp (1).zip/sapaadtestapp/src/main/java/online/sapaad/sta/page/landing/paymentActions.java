
	package online.sapaad.sta.page.landing;

	import java.util.ArrayList;
	import java.util.List;
	import java.util.concurrent.TimeUnit;

	import org.apache.log4j.Logger;
	import org.openqa.selenium.By;
	import org.openqa.selenium.JavascriptExecutor;
	import org.openqa.selenium.NoSuchElementException;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.interactions.Actions;
	import org.openqa.selenium.support.ui.ExpectedConditions;
	import org.openqa.selenium.support.ui.FluentWait;
	import org.openqa.selenium.support.ui.Select;
	import org.openqa.selenium.support.ui.WebDriverWait;
	import org.testng.Assert;

	import com.google.common.base.Function;

	import online.sapaad.sta.driver.WaitManager;
	import online.sapaad.sta.driver.WebElementManager;
	import online.sapaad.sta.page.landing.order.OrderItemData;
	import online.sapaad.sta.payment.PaymentData;

	public class paymentActions {
		public final static Logger logger = Logger.getLogger(OrderActions.class);
		public final static String sectionElementsXpath = "//*[@id=\"main\"]/div/div[2]/div/div/div[1]/div/div/section[@class=\"starters-block\"]";

		public static boolean isCustomizeFound(String innnerHtml) {
			logger.info("----CHECKING CUSTOMIZE FOUND OR NOT---/n"+ innnerHtml);
			boolean isFound = innnerHtml != null && innnerHtml.contains("<a href=\"javascript:void(0)\">Customize</a>") ? true : false;
			logger.info("---- IS CUSTOMIZED ITEM FOUND: ?---" + isFound);
			return isFound;

		}

		public static void addItemsToCart(WebDriver driver, PaymentData ptdata) throws InterruptedException {
			// TODO Auto-generated method stubs
			int cartItemCount = 0;
			boolean isLocationSelected = false;
			boolean isPickupLocationSelected = false;
			List<WebElement> listOfStarterSection = WebElementManager.getElementsByXpathAfterFWait(driver, 10000, 1000, sectionElementsXpath);
			List<String> addedItems = new ArrayList<String>();
			searchItem:

			for (int sectionCount = 1; sectionCount <= listOfStarterSection.size(); sectionCount++) {
				WebElement selectionElement = WebElementManager.getElementByXpathAfterFWait(driver, 10000, 1000, sectionElementsXpath + "[" + sectionCount + "]");
				// System.out.println(selectionElement.getAttribute("innerHTML"));
				List<WebElement> items = selectionElement.findElements(
						By.xpath(sectionElementsXpath + "[" + sectionCount + "]/div/div/div/div[@class='items']"));
				String innerHtml = null;
				String itemDescription = null;
				WebElement itemElement = null;
				for (int itemsCount = 1; itemsCount <= items.size(); itemsCount++) {
					itemElement = WebElementManager.getElementByXpathAfterFWait(driver, 10000, 1000, sectionElementsXpath + "[" + sectionCount
							+ "]/div/div/div/div[@class='items'][" + itemsCount + "]");
					try {
						innerHtml = itemElement.getAttribute("innerHTML");
					} catch (Exception e) {
						continue;
					}
					itemDescription = doAddItemAction(itemElement, driver, addedItems);
					if (itemDescription == null || innerHtml == null)
						continue;// skipping current iteration, moving to next iteration
					break;

				} // End of section items for loop
				if (isCustomizeFound(innerHtml)) {
					logger.info("Customize Found for the item:" + itemDescription);
					doCustomization(itemElement);
				}
				if(null != ptdata.getDeliveryLocation() && !ptdata.getDeliveryLocation().isEmpty()) {
					logger.info("Choose Delivery location as "+ptdata.getDeliveryLocation());
				/** selecting location iff it is not selected already */
				isLocationSelected = isLocationSelected ? true : selectDeliveryLocation(driver, ptdata);
				logger.info("isLocationSelected "+isLocationSelected);
				}else {
					logger.info("Choose PickUp Location");
					isPickupLocationSelected = isPickupLocationSelected ? true : choosePickUpLocation(driver, ptdata);
				}
				WaitManager.applyJavaWait(1000);
				boolean isItemAdded = isItemAddedToOrderList(driver, itemDescription);
				if (isItemAdded) {
					cartItemCount++;
					addMoreQuantity(itemDescription, driver);
					logger.info("----AFTER ADD MORE QUANTITY---");
					WaitManager.applyJavaWait(1000); 
					driver.navigate().refresh();
					WaitManager.applyJavaWait(1000);
					listOfStarterSection = driver.findElements(By.xpath(sectionElementsXpath));
					logger.info("----BREAKING THE ITERATION & MOVING TO NEW ITERATION---");
					// isLocationSelected = false;
					// isPickupLocationSelected = false;
					itemDescription = null;
					itemElement = null;
					continue searchItem; // breaking the iteration and moving for new iteration
				}
				if (cartItemCount == 2) {
					break;
				}
			}

		}

		
		
		public static void doCustomization(WebElement itemElement) {
			WebElement customizePopUp = itemElement.findElement(By.className("customize-popup"));
			List<WebElement> lists = customizePopUp.findElements(By.cssSelector(".list-unstyled.checklist"));
			for (WebElement list : lists) {
				try {
				WebElement incrementBtn = list.findElement(By.className("jcf-btn-inc"));
				incrementBtn.click();
				}catch(Exception e) {
					
				}
			}
			WebElement addToCartBtn = customizePopUp.findElement(By.className("btn-success"));
			addToCartBtn.click();
		}
		

		public static String doAddItemAction(WebElement itemElement, WebDriver driver, List<String> addedItems) {
			logger.info("----PERFORMING ADD ITEM ACTION---");
			WebElement ele = itemElement.findElement(By.className("text"));
			WebElement ele2 = ele.findElement(By.className("title-holder"));
			WebElement ele3 = ele2.findElement(By.tagName("strong"));
			WebElement ele4 = ele3.findElement(By.tagName("a"));
			WaitManager.applyJavaWait(2000);
			String itemDescription = ele4.getAttribute("innerHTML");
			logger.info("itemDescription==" + itemDescription);
			if (!addedItems.contains(itemDescription)) {
				addedItems.add(itemDescription);
				WaitManager.applyJavaWait(2000);
				WebElement priceBar = itemElement.findElement(By.className("price-bar"));
			WaitManager.applyJavaWait(5000);
			
				WebElement addBtn = priceBar.findElement(By.tagName("a"));
				WaitManager.applyJavaWait(2000);
				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("arguments[0].click();", addBtn);
			} else {
				itemDescription = null;
			}
			logger.info("----END OF ADD ITEM ACTION---");
			return itemDescription;
		}
		public static boolean choosePickUpLocation(WebDriver driver, PaymentData ptdata) {
			boolean isLocationSelected = false;
			//WaitManager.applyJavaWait(5000);
			WaitManager.applyJavaWait(1000);
			WebElement popUpHolder = driver.findElement(By.cssSelector(".popupholder .main-popup .mainpopup-holder"));
			WebElement pickupLink = popUpHolder.findElement(By.partialLinkText("Pickup from restaurant"));
			WebElementManager.clickByJSExecutor(pickupLink, driver);
			//WaitManager.applyJavaWait(5000);
			WaitManager.applyJavaWait(1000);
			WebElement continueOrderingButton = driver.findElement(By.cssSelector(".pickup-footer input"));
			WebElementManager.clickByJSExecutor(continueOrderingButton, driver);
			isLocationSelected = true; 
			return isLocationSelected;
			
		}

		public static boolean selectDeliveryLocation(WebDriver driver, PaymentData ptdata) {
			boolean isLocationSelected = false;
			try {
				logger.info("Entered into selectDeliveryLocation");
				WebElement popUpHolder = WebElementManager.getElementByXpathAfterFWait(driver, 10000, 1000, "//*[@id=\"main\"]/div/div[2]/div/div[2]/div/div");
				// WebElement popUpHolder = driver.findElement(By.xpath("//*[@id=\"main\"]/div/div[2]/div/div[2]/div/div"));
				WebElement popholderChild = popUpHolder
						.findElement(By.xpath("//*[@id=\"main\"]/div/div[2]/div/div[2]/div/div/form/div"));
				WebElement popUpHolderChildChild = popholderChild
						.findElement(By.xpath("//*[@id=\"main\"]/div/div[2]/div/div[2]/div/div/form/div/div"));
				WebElement deliveryLocation = popUpHolderChildChild
						.findElement(By.xpath("//*[@id=\"main\"]/div/div[2]/div/div[2]/div/div/form/div/div/div"));
				deliveryLocation.click();
				WaitManager.applyJavaWait(1000);
				int locationLiIndex = getListElementIndexByLocation(driver, ptdata);
				logger.info("locationLiIndex=="+locationLiIndex);
				WebElement selectLocation = deliveryLocation.findElement(
						By.xpath("//*[@id=\"main\"]/div/div[2]/div/div[2]/div/div/form/div/div/div/div/ul/li["+locationLiIndex+"]"));
				selectLocation.click();
				WaitManager.applyJavaWait(1000);
				WebElement continueOrderingBtn = driver
						.findElement(By.xpath("//*[@id=\"main\"]/div/div[2]/div/div[2]/div/div/form/div/div/input"));
				continueOrderingBtn.click();

				WaitManager.applyJavaWait(1000);
				isLocationSelected = true;
			} catch (Exception e) {
	isLocationSelected = false;
			}
			logger.info("End of selectDeliveryLocation");
			return isLocationSelected;
		}
		public static int getListElementIndexByLocation(WebDriver driver, PaymentData ptdata) {
			String locationToBeSelected = ptdata.getDeliveryLocation();
			logger.info("------Location to be selected------"+locationToBeSelected);
			
			//WaitManager.applyJavaWait(1000);
			//List<WebElement> locationLists = driver.findElements(By.xpath("//*[@id=\"main\"]/div/div[2]/div/div[2]/div/div/form/div/div/div/div/ul/li"));
		     
			
			List<WebElement> locationLists = WebElementManager.getElementsByXpathAfterFWait(driver, 10000, 1000, "//*[@id=\"main\"]/div/div[2]/div/div[2]/div/div/form/div/div/div/div/ul/li");
			int listNumber = 0;
		     boolean isLocationFound = false;
		     logger.info("location List size ===="+(null !=locationLists?locationLists.size(): 0));
			for (WebElement webElement : locationLists) {
				listNumber++;
				
				String innerHTML = webElement.getAttribute("innerHTML");
			 logger.info("Location Inner Html ==\n"+ webElement.getAttribute("innerHTML"));
				if(innerHTML.indexOf(ptdata.getDeliveryLocation())>0) {
					isLocationFound = true;
					logger.info(locationToBeSelected+" is found at the list :"+listNumber);
					break;
				}
			
			}
			listNumber = isLocationFound ? listNumber : 0;
			return listNumber;
		}

		public static boolean isItemAddedToOrderList(WebDriver driver, String itemDescription) {
			logger.info("ENTERED INTO isItemAddedToOrderList itemDescription=" + itemDescription);
			boolean isAdded = false;
			WebElement orderedItemDiv = WebElementManager.getElementByIdAfterFWait(driver, 10000, 1000, "order_div");
		
			try {
			
				WebElement orderedItem = orderedItemDiv.findElement(By.partialLinkText(itemDescription));
				isAdded = true;
			} catch (Exception e) {
				// Assert.fail("Selected Item "+ itemDescription +"is not Added to ordered Item
				// List");
				// logger.info("Test Failed: Selected Item"+ itemDescription +" is not Added to
				// ordered Item List");
			}
			return isAdded;

		}

		public static void addMoreQuantity(String itemDescription, WebDriver driver) {
			logger.info("ENTERED INTO addMoreQuantity itemDescription=" + itemDescription);
			WebElement orderedItemDiv = driver.findElement(By.id("order_div"));
			List<WebElement> items = orderedItemDiv.findElements(By.className("added-items"));
			WebElement item = items.stream().filter(element -> element.getAttribute("innerHTML").contains(itemDescription))
					.findFirst().orElse(null);
			String quantityB4Incr = item.findElement(By.xpath("//*[@class=\"jcf-real-element\"]")).getAttribute("value");
			logger.info("QUANTITY BEFORE INCREMENT=" + quantityB4Incr);
			WebElement incrementBtn = item.findElement(By.xpath("//*[@class=\"jcf-btn-inc\"]"));
			incrementBtn.click();
			WaitManager.applyJavaWait(2000);
			// *[@class="jcf-real-element"]
			orderedItemDiv = driver.findElement(By.id("order_div"));
			items = orderedItemDiv.findElements(By.className("added-items"));
			item = items.stream().filter(element -> element.getAttribute("innerHTML").contains(itemDescription)).findFirst()
					.orElse(null);
			WebElement web = item.findElement(By.xpath("//*[@class=\"jcf-real-element\"]"));
			JavascriptExecutor js = (JavascriptExecutor) driver;
			String quantityAfterInc = (String) js.executeScript("return arguments[0].value;", web);
			logger.info("QUANTITY AFTER INCREMENT=" + quantityAfterInc);
			if (Integer.parseInt(quantityAfterInc) > Integer.parseInt(quantityB4Incr)) {
				logger.info("QUANTITY INCREMENTED for the item: " + itemDescription);
			} else {
				logger.info("QUANTITY NOT CHANGED");
				Assert.fail("Quantity is not incremented for the item: " + itemDescription);
				logger.info("Test Failed: Quantity is not incremented for the item: " + itemDescription);
			}

		}

		public static void doCheckout(WebDriver driver) {
			WaitManager.applyJavaWait(4000);
			driver.findElement(By.id("continueToDelivery")).click();
		}
		public static boolean selectMatchedLocation(WebDriver driver,  PaymentData ptdata) {
			// .radio-list .radio-box
			boolean isAddressfound = false;
			List<WebElement> addresses = driver.findElements(By.cssSelector(".radio-list .radio-box"));
			int addressCount = 0 ;
			for (WebElement address : addresses) {
				String innerHTML =  address.getAttribute("innerHTML");
				addressCount++;
				if(innerHTML.indexOf(ptdata.getDeliveryLocation()) > -1) {
					logger.info("Location "+ptdata.getDeliveryLocation()+" found");
					WebElementManager.clickByJSExecutor(address, driver);
					isAddressfound = true;
					break;
				}
				
			}
			return isAddressfound;
		}

		public static void addNewAddress(WebDriver driver, PaymentData pdata) {
			WaitManager.applyJavaWait(4000);
			WebElement addNewAddress=driver.findElement(By.partialLinkText("Add new address"));
			WaitManager.applyJavaWait(4000);
			addNewAddress.click();
			WaitManager.applyJavaWait(4000);
			driver.findElement(By.cssSelector(".main-popup.add-address")).findElement(By.cssSelector(".btn.btn-success"))
					.click();
			WaitManager.applyJavaWait(5000);
			logger.info(pdata);
			driver.findElement(By.id("delivery_1")).sendKeys(pdata.getBuilding());
			WaitManager.applyJavaWait(2000);
			driver.findElement(By.id("delivery_2")).sendKeys(pdata.getStreet());
			WaitManager.applyJavaWait(2000);
			driver.findElement(By.id("delivery_3")).sendKeys(pdata.getFlatNumber());
			WaitManager.applyJavaWait(2000);
			driver.findElement(By.id("delivery_4")).sendKeys(pdata.getLandMark());
			WaitManager.applyJavaWait(2000);
			driver.findElement(By.cssSelector(".main-popup.step_two.add-address"))
					.findElement(By.cssSelector(".btn.btn-success")).click();
			logger.info("---END OF ADD ADDRESS---");
		}

		public static void doPayment(WebDriver driver, PaymentData pdata) {
			WaitManager.applyJavaWait(4000);
//			driver.findElement(By.cssSelector(".delivery-detail.slide")).findElement(By.cssSelector(".btn.btn-success"))
//					.click();
			if(pdata.getDeliveryLocation()!=null && !pdata.getDeliveryLocation().isEmpty()) {
			WebElement ele =driver.findElement(By.cssSelector(".order-info.opened .delivery-detail.slide .detail-holder .popup-slide.deliverydet-slide .popupslide-frame")).findElement(By.partialLinkText("CONTINUE TO PAYMENT"));
			// .click();
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", ele);
			logger.info("---CONTINUE TO PAYMENT---");
			}
			if("yes".equalsIgnoreCase(pdata.getLoyality())) {
				logger.info("REDEEM LOYALTY POINTS");
				redeemLoyaltyPoints(driver);
			}
			
			applyDiscountCode(driver, pdata);
			logger.info("Payment Type =="+pdata.getPaymentType());
			switch (pdata.getPaymentType()) {
			case "CASH_ON_DELIVERY":
				doCashOnDelivery(driver);
				break;
			case "CARD_ON_DELIVERY":
				doCardOnDelivery(driver);
				break;
			case "STRIPE":
				doStripeCard(driver,pdata);
				break;
			case "PAYTAB":
				doPayTab(driver,pdata);
				break;
			default:
				doCashOnDelivery(driver);
				break;
			}

		}

		public static void redeemLoyaltyPoints(WebDriver driver) {
			logger.info("---redeemLoyaltyPoints---");
			WaitManager.applyJavaWait(4000);
			try {
				driver.findElement(By.cssSelector(".payment-slide.popup-slide"))
						.findElement(By.cssSelector(".jcf-checkbox")).click();
			} catch (Exception e) {
				// e.printStackTrace();
			}

		}

		public static void applyDiscountCode(WebDriver driver, PaymentData pdata) {
			logger.info("---applyDiscountCode---");
			if (null != pdata.getDiscountCode() && !pdata.getDiscountCode().isEmpty()) {
				WaitManager.applyJavaWait(4000);
				try {
					logger.info("---discount code is not empty ---"+pdata.getDiscountCode());
					driver.findElement(By.cssSelector(".payment-slide.popup-slide")).findElement(By.cssSelector("#dcode"))
							.sendKeys(pdata.getDiscountCode());
					driver.findElement(By.cssSelector(".payment-slide.popup-slide"))
							.findElement(By.partialLinkText("APPLY")).click();

				} catch (Exception e) {
	                // e.printStackTrace();
				}
			}
			logger.info("---End of applyDiscountCode---");
		}

		public static void doCashOnDelivery(WebDriver driver) {
			// TODO Auto-generated method stub
			WaitManager.applyJavaWait(2000);
			logger.info("###Do cash On Delivery");
			WaitManager.applyJavaWait(2000);
			driver.findElement(By.cssSelector(".cash-delivery")).findElement(By.cssSelector(".btn.btn-success")).click(); 
		}
		public static void sapaadSettings(WebDriver driver) {
			// TODO Auto-generated method stub
			WaitManager.applyJavaWait(2000);
			logger.info("###Sapaad settings");
			WaitManager.applyJavaWait(2000);

			//	WebElementManager.clickByJSExecutor(driver.findElement(By.cssSelector(".dropdown.pdaUP")), driver);
				WebElement logoutIcon=driver.findElement(By.xpath("//*[@id=\"topMenuBar\"]/div/div/div/ul[3]/li[2]/a/i"));
				WaitManager.applyJavaWait(4000);
				logoutIcon.click();
				
				}
		public static void sapaadSetup(WebDriver driver) {
			// TODO Auto-generated method stub
			WaitManager.applyJavaWait(2000);
			logger.info("###Sapaad setup");
			WebElement setUp=driver.findElement(By.xpath("//*[@id=\"topMenuBar\"]/div/div/div/ul[3]/li[2]/ul/li[3]/a"));	
			setUp.click();
				}
		public static void closeThankYouWindow(WebDriver driver) {
			logger.info("###closeThankYouWindow");
			WaitManager.applyJavaWait(8000);
			WebElement parentElement = driver.findElement(By.cssSelector(".popup-overlay.v2"));
			WebElement closeThankYou=parentElement.findElement(By.cssSelector(".main-popup.interaction-popup")).findElement(By.cssSelector(".close.icon-close"));
			WaitManager.applyJavaWait(6000);
			closeThankYou.click(); 
		}

		public static void doCardOnDelivery(WebDriver driver) {
			// TODO Auto-generated method stub
			WaitManager.applyJavaWait(2000);
			driver.findElement(By.cssSelector(".payment-tabs")).findElement(By.id("react-tabs-2")).click();
			WaitManager.applyJavaWait(2000);
			driver.findElement(By.cssSelector(".cash-delivery")).findElement(By.cssSelector(".btn.btn-success")).click(); // Confirm
																															// Order
		}

		public static void doStripeCard(WebDriver driver,PaymentData pdata) {
			// TODO Auto-generated method stub
			// div.credit-delivery
			// savedcards
			WaitManager.applyJavaWait(2000);
			driver.findElement(By.cssSelector(".payment-tabs")).findElement(By.id("react-tabs-4")).click();
			WaitManager.applyJavaWait(2000);
			boolean isSavedCards = false;
			try {
			WebElement creditDeliveryDiv = driver.findElement(By.cssSelector("div.credit-delivery"));
			String innerHtml =  creditDeliveryDiv.getAttribute("innerHTML");
			logger.info("------Credit Delivery Div /n"+innerHtml);
			if(innerHtml.indexOf("Select your saved card")>-1) {
				logger.info(" SAVED CARDS FOUND");
				isSavedCards = true;
			}
			}catch(Exception e) {
				isSavedCards = false;
			}
			if(!isSavedCards) {
			driver.switchTo().frame("__privateStripeFrame4");
			WaitManager.applyJavaWait(4000);
			//driver.findElement(By.xpath("//*[@id=\"react-tabs-5\"]/div/div[1]/div[2]/label/span[1]")).click();
			// driver.findElement(By.name("cardnumber")).sendKeys(odata.getCardNumber());
			logger.info("CARD NUMBER:"+pdata.getCardNumber());
			Actions action = new Actions(driver); 
		//	driver.findElement(By.xpath("//*//*[@id=\"react-tabs-5\"]/div/div[1]/div[2]/label/span[1]/input")).click();
			WebElement element = driver.findElement(By.name("cardnumber"));
			//action.moveToElement(element).click().perform();
	        // long num = Long.parseLong(odata.getCardNumber());
			String num = pdata.getCardNumber();
			action.moveToElement(element).sendKeys(element, num).build().perform();
			// action.moveToElement(element).sendKeys(element, "4111111111111111").build().perform();
			// element.clear();
			// element.click();
			//JavascriptExecutor jse = (JavascriptExecutor) driver;
	//jse.executeScript("arguments[0].value='4111111111111111';",element);

			String arr[] = pdata.getExpiryDate().split("/");
			driver.findElement(By.name("cc-exp-month")).sendKeys(arr[0]);
			driver.findElement(By.name("cc-exp-year")).sendKeys(arr[1]);
			driver.findElement(By.name("cc-cvc")).sendKeys(pdata.getCvv());
			driver.switchTo().defaultContent();
			}
			WaitManager.applyJavaWait(2000);
			driver.findElement(By.cssSelector(".cardinfo-holder")).findElement(By.cssSelector(".btn.btn-success")).click();

		}

		public static void doPayTab(WebDriver driver, PaymentData ptdata) {
			// TODO Auto-generated method stub
			WaitManager.applyJavaWait(2000);
			driver.findElement(By.cssSelector(".payment-tabs")).findElement(By.id("react-tabs-6")).click();
			WaitManager.applyJavaWait(2000);
			driver.findElement(By.cssSelector(".cash-delivery")).findElement(By.cssSelector(".btn.btn-success")).click(); // Confirm
			WaitManager.applyJavaWait(2000);																								// Order
			driver.findElement(By.id("cc_number")).sendKeys(ptdata.getCardNumber());
			WaitManager.applyJavaWait(2000);
			driver.findElement(By.id("cvv")).sendKeys(ptdata.getCvv());
			WaitManager.applyJavaWait(2000);
			WebElement expiry_month = driver.findElement(By.id("expiry_month"));
			Select select = new Select(expiry_month);
			select.selectByVisibleText(ptdata.getExpiryMonth());
			WebElement expiry_year = driver.findElement(By.id("expiry_year"));
			Select selectyear = new Select(expiry_year);
			selectyear.selectByVisibleText(ptdata.getExpiryYear());
			WaitManager.applyJavaWait(2000);
			driver.findElement(By.cssSelector(".btn.btn-lg.btn-block.btn-success")).click();
			approvePaymentGatewayAlert(driver);
			//driver.findElement(By.cssSelector(".cardinfo-holder")).findElement(By.cssSelector(".btn.btn-success")).click();
			WaitManager.applyJavaWait(15000);

		}

		public static void doLogin(WebDriver driver,PaymentData ptdata) {
			logger.info("ENTERED INTO DOLOGIN-");
			try {
				
				try {
					driver.navigate().refresh();
					WaitManager.applyJavaWait(2000);
						WebElement loginSectiondiv = WebElementManager.getElementByXpathAfterFWait(driver, 10000, 1000, "//div[@class=\"login_section\"]");
	            loginSectiondiv.findElement(By.partialLinkText("Sign In")).click();
				}catch(Exception e) {
					try {
					 LandingPageActions.doLogout(driver);
					 driver.navigate().refresh();
					 WebElement loginSectiondiv = WebElementManager.getElementByXpathAfterFWait(driver, 10000, 1000, "//div[@class=\"login_section\"]");
			            loginSectiondiv.findElement(By.partialLinkText("Sign In")).click();
					}catch(Exception e2) {
						WebElement loginSectiondiv = WebElementManager.getElementByXpathAfterFWait(driver, 10000, 1000, "//div[@class=\"login_section\"]");
			            loginSectiondiv.findElement(By.partialLinkText("Sign In")).click();
					}
				}
	            WebElement parentEle = WebElementManager.getElementByXpathAfterFWait(driver, 10000, 1000, "//*[@id=\"header\"]/div/div/div[2]/div/div/form");
	            parentEle.findElement(By.id("phone")).sendKeys(ptdata.getUserName());
				
				WaitManager.applyJavaWait(2000);
				
				parentEle
				.findElement(By.xpath(LandingPageConstants.LOGIN_XPATH_SIGN_IN_CONTINUE_BTN)).click();
				 WebElement passwordElement = WebElementManager.getElementByXpathAfterFWait(driver, 10000, 1000, "//*[@id=\"header\"]/div/div/div[2]/div/div/form/div[2]/input");
				String js = "arguments[0].style.height='auto'; arguments[0].style.visibility='visible';";
				// Execute the Java Script for the element which we find out
				((JavascriptExecutor) driver).executeScript(js, passwordElement);
				passwordElement.sendKeys(ptdata.getPassword());
				WebElement submitElement = WebElementManager.getElementByXpathAfterFWait(driver, 10000, 1000, "//*[@id=\"header\"]/div/div/div[2]/div/div/form/input[@type='submit']");
				WebElementManager.clickByJSExecutor(submitElement, driver);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		public static void approvePaymentGatewayAlert(WebDriver driver) {
			WaitManager.applyJavaWait(2000);
			driver.switchTo().alert().accept();
			WaitManager.applyJavaWait(10000);
		}
		public static void doLoginAdminPanel(WebDriver driver) {
			driver.get("http://review.sapaad.com");
			driver.findElement(By.id("user_email")).sendKeys("online_test@ativistar.com");
			WaitManager.applyJavaWait(2000);
			driver.findElement(By.id("user_password")).sendKeys("abcd1234");
			WaitManager.applyJavaWait(2000);
			driver.findElement(By.xpath("//*[@id=\"new_user\"]/div[2]/button")).click();
					
		}
		public static void doOnlineMenuClick(WebDriver driver) {
		
			WebElement onlineTab=driver.findElement(By.cssSelector(".nav.tourTopNavigation")).findElement(By.partialLinkText("Online"));
			WaitManager.applyJavaWait(2000);
			onlineTab.click();
			WaitManager.applyJavaWait(2000);
			
		}
		public static void doDeliveryManagerMenuClick(WebDriver driver, String orderID, PaymentData ptdata) throws InterruptedException {
			driver.findElement(By.cssSelector(".nav.tourTopNavigation")).findElement(By.partialLinkText("Delivery Manager")).click();
			WaitManager.applyJavaWait(3000);
			driver.findElement(By.xpath("//*[@id=\"topMenuBar\"]/div/div/div/ul[1]/li[6]/ul/li[1]")).click();
			WaitManager.applyJavaWait(3000);
			int orderFoundRow = getOrderNumberRowInDeiveryManager(driver, orderID);
			if(orderFoundRow != 0 ) {
				WebElement readyButton = driver.findElement(By.xpath("//*[@id='neworder']/table/tbody/tr["+orderFoundRow+"]/td[6]/form/button"));
				// readyButton.click();
				WebElementManager.clickByJSExecutor(readyButton, driver);
				WaitManager.applyJavaWait(3000);
				WebElement waiting4pickTab = driver.findElement(By.xpath("//*[@id=\"dm_waiting_to_pick\"]"));
				WaitManager.applyJavaWait(3000);
				waiting4pickTab.click();
				WaitManager.applyJavaWait(3000);
				WebElement selectDriver = driver.findElement(By.xpath("//*[@id=\"selected_driver\"]"));
				WaitManager.applyJavaWait(3000);
			//	Select selectDriverSelect = new Select(selectDriver);
			//	selectDriverSelect.selectByVisibleText(ptdata.getDriver());
				WaitManager.applyJavaWait(3000);
				//*[@id="newOrderListForm"]/button
				orderFoundRow = getOrderNumberRowInWaiting4Pick(driver, orderID);
				if(orderFoundRow != 0 ) {
					WebElement amountToPayElement = driver.findElement(By.xpath("//*[@id=\"waitingforpick\"]/div[2]/table/tbody/tr["+orderFoundRow+"]/td[6]"));
					String amountWithAED = amountToPayElement.getAttribute("innerHTML");
					String[] amountWithAEDArray =amountWithAED.split(" ");
					String amountToPay = amountWithAEDArray[0].trim();
					logger.info("Amount to Pay: "+amountToPay);
				
					WebElement pickUpButton = driver.findElement(By.xpath("//*[@id=\"waitingforpick\"]/div[2]/table/tbody/tr["+orderFoundRow+"]/td[7]/form/button"));
					// readyButton.click();	
					WaitManager.applyJavaWait(5000);
					WebElementManager.clickByJSExecutor(pickUpButton, driver);
					WaitManager.applyJavaWait(5000);
					WebElement deliveryInProgress = driver.findElement(By.xpath("//*[@id=\"dm_inprogress\"]"));
					WaitManager.applyJavaWait(5000);
					deliveryInProgress.click();
					WaitManager.applyJavaWait(5000);
					
					
					orderFoundRow = getOrderNumberRowInDeliveryInProgress(driver, orderID);
					String paymentType = ptdata.getPaymentType();
					logger.info("Payment Type: "+paymentType);
					String actionElement = "button";
					//if(paymentType!= null && ("PAYTAB".equals(paymentType) ||  "CASH_ON_DELIVERY".equals(paymentType) ||  "CARD_ON_DELIVERY".equals(paymentType))) { //
					if(paymentType!= null && ("CASH_ON_DELIVERY".equals(paymentType) ||  "CARD_ON_DELIVERY".equals(paymentType))) { //
					actionElement = "a";
					WaitManager.applyJavaWait(5000);
					WebElement deliveredButton = driver.findElement(By.xpath("//*[@id=\"ondelivery\"]/div[1]/table/tbody/tr["+orderFoundRow+"]/td[7]/" + actionElement));
					// readyButton.click();
				
					WaitManager.applyJavaWait(2000);
					WebElementManager.clickByJSExecutor(deliveredButton, driver);
					WaitManager.applyJavaWait(2000);
					
					
				
				
					}else if(paymentType!= null && ("STRIPE".equals(paymentType)) || ("PAYTAB".equals(paymentType))) { //||  "STRIPE".equals(paymentType)
					//	actionElement = "form/button";
						System.out.println("found");
						WaitManager.applyJavaWait(2000);
						WebElement deliveredLink = driver.findElement(By.xpath("//*[@id=\"newOrderListForm\"]/button"));
						WaitManager.applyJavaWait(4000);
						deliveredLink.click();
						// readyButton.click();
						WaitManager.applyJavaWait(4000);
						
						
				
					}
					
					if(paymentType!= null && ("CARD_ON_DELIVERY".equals(paymentType) ||  "CASH_ON_DELIVERY".equals(paymentType))) {
					Thread.sleep(2000);
						doPaymentDetails(driver, orderID, amountToPay);
						WebElement payOKButton = driver.findElement(By.xpath("//*[@id=\"orderPaymentForm\"]/a"));
						// okButton.click();
						WaitManager.applyJavaWait(2000);
						payOKButton.click();
						WaitManager.applyJavaWait(2000);
					}
					
					
					
				}
			}
		}
	public static void doAfterpaymentOkButton(WebDriver driver) {
			
			
			WebElement payOKButton = driver.findElement(By.xpath("//*[@id=\"orderPaymentForm\"]/a"));
			// okButton.click();
			WaitManager.applyJavaWait(2000);
			payOKButton.click();
			WaitManager.applyJavaWait(1000);
			
		}
		public static void doPaymentDetails(WebDriver driver, String orderID,String amountToPay) throws InterruptedException {
			logger.info("ENTERED INTO doPaymentDetails METHOD ");
			WaitManager.applyJavaWait(3000);

			WebElement popPayWindow = driver.findElement(By.xpath("//*[@id=\"popPayNowWindow\"]/div/div[2]/div/div[4]/div/div[1]/input[1]"));
			//Enter payment
			WaitManager.applyJavaWait(3000);

			popPayWindow.sendKeys(amountToPay);
			WaitManager.applyJavaWait(3000);
			
		
			WebElement payButton = driver.findElement(By.xpath("//*[@id=\"orderPaymentForm\"]/button"));
			// payButton.click();
			WaitManager.applyJavaWait(1000);
			WebElementManager.clickByJSExecutor(payButton, driver);
			WaitManager.applyJavaWait(1000);
			
			WebElement popPayCardNumberWindow = driver.findElement(By.xpath("//*[@id=\"popPayNowWindow\"]/div/div[2]/div/div[4]/div/div[2]/input[1]"));
			//Enter card number
			 popPayCardNumberWindow.sendKeys("1234");
			WaitManager.applyJavaWait(1000);
			
			//*[@id="orderPaymentForm"]/button
			
			WebElement btnPayNow = driver.findElement(By.cssSelector(".btn.btn-large.pull-right.btnPayNow.btn-success"));
			// payButton.click();
			WaitManager.applyJavaWait(1000);
			WebElementManager.clickByJSExecutor(btnPayNow, driver);
			WaitManager.applyJavaWait(1000);
		}
		public static void doOrderReviewByAdmin(WebDriver driver, String orderID) throws InterruptedException {
			int orderFoundRow = getOrderNumberRow(driver,orderID);
			WaitManager.applyJavaWait(2000);
			if(orderFoundRow != 0 ) {
				logger.info("ORDER FOUND FOR REVIEW");
				WebElement reviewButton = driver.findElement(By.xpath("//*[@id=\"unconfirmed\"]/table/tbody/tr["+orderFoundRow+"]/td[6]/button"));
				// reviewButton.click();
				WaitManager.applyJavaWait(1000);
				WebElementManager.clickByJSExecutor(reviewButton, driver);
				WaitManager.applyJavaWait(3000);
				WebElement confirmButtom = driver.findElement(By.xpath("//*[@id=\"readyOrderForm\"]/div[3]/button"));
				// confirmButtom.click();
				WaitManager.applyJavaWait(2000);
				WebElementManager.clickByJSExecutor(confirmButtom, driver);
				if(isManagerShowDetailedInfo(driver)) {
					WaitManager.applyJavaWait(2000);
					// //*[@id="deliveryManagerShowDetailedInfo"]/div/div/div[2]/div[1]/div[2]/footer/a[2]
					WebElement close = driver.findElement(By.xpath("//*[@id=\"deliveryManagerShowDetailedInfo\"]/div/div/div[2]/div[1]/div[2]/footer/a[2]"));
				//	WaitManager.applyJavaWait(5000);
					//Thread.sleep(2000);
					close.click();

					// OrderActions.doAdminLogout(driver);
					Assert.fail("Test failed due to internal Server for managerShowDetailedInfo");
				}else {
					// OrderActions.doAdminLogout(driver);
				}
				
			}else {
				logger.info("ORDER NOT FOUND FOR REVIEW");
				Assert.fail("ORDER NOT FOUND FOR REVIEW");
			}
		}
		public static String getOrderID(WebDriver driver) {
			WaitManager.applyJavaWait(2000);
			String orderNumber = driver.findElement(By.partialLinkText("Order Number:")).getAttribute("innerHTML");
			String[] orderNumArray =  orderNumber.split(":");
			orderNumber = orderNumArray[1];
			logger.info("Order Number ==" + orderNumber);
			return cleanTextContent(orderNumber);
		}
		public static boolean isManagerShowDetailedInfo(WebDriver driver) {
			
			WaitManager.applyJavaWait(2000);
			try {
			WebElement managerShowDetailedInfo = driver.findElement(By.id("deliveryManagerShowDetailedInfo"));
			if(null != managerShowDetailedInfo) {
				logger.info("managerShowDetailedInfo found");
				return true;
			}else {
				return false;
			}}
			catch(Exception e) {
				return false;
			}
		}
		private static String cleanTextContent(String text)
		{
		    // strips off all non-ASCII characters
		    text = text.replaceAll("[^\\x00-\\x7F]", "");
		 
		    // erases all the ASCII control characters
		    text = text.replaceAll("[\\p{Cntrl}&&[^\r\n\t]]", "");
		     
		    // removes non-printable characters from Unicode
		    text = text.replaceAll("\\p{C}", "");
		 
		    return text.trim();
		}
		public static int getOrderNumberRow(WebDriver driver, String orderNumber) {
			logger.info("------ORDER NUMBR------"+orderNumber);
			logger.info("------ORDER NUMBR length------"+orderNumber.length());
			orderNumber = orderNumber.trim();
			logger.info("------ORDER NUMBR length------"+orderNumber.length());
			WaitManager.applyJavaWait(5000);
			List<WebElement> unconfirmedOrderTableBodyRows = driver.findElements(By.cssSelector(".table.marginBottom60.newOnlineOrderingOrders tbody tr"));
		     int rowNumber = 0;
		     boolean isOrderFound = false;
		     logger.info("unconfirmedOrderTableBodyRows===="+(null !=unconfirmedOrderTableBodyRows?unconfirmedOrderTableBodyRows.size(): 0));
			for (WebElement webElement : unconfirmedOrderTableBodyRows) {
				rowNumber++;
				// logger.info("Inner Html ==\n"+ webElement.getAttribute("innerHTML"));
				String innerHTML = webElement.getAttribute("innerHTML");
				if(innerHTML.indexOf(orderNumber)>0) {
					isOrderFound = true;
					logger.info(orderNumber+" is found at the row :"+rowNumber);
					break;
				}
			
			}
			rowNumber = isOrderFound ? rowNumber : 0;
			return rowNumber;
		}
		public static int getOrderNumberRowInDeiveryManager(WebDriver driver, String orderNumber) {
			logger.info("------ORDER NUMBR------"+orderNumber);
			logger.info("------ORDER NUMBR length------"+orderNumber.length());
			orderNumber = orderNumber.trim();
			logger.info("------ORDER NUMBR length------"+orderNumber.length());
			WaitManager.applyJavaWait(5000);
			List<WebElement> unconfirmedOrderTableBodyRows = driver.findElements(By.xpath("//*[@id=\"neworder\"]/table/tbody/tr"));
		     int rowNumber = 0;
		     boolean isOrderFound = false;
		     logger.info("unconfirmedOrderTableBodyRows===="+(null !=unconfirmedOrderTableBodyRows?unconfirmedOrderTableBodyRows.size(): 0));
			for (WebElement webElement : unconfirmedOrderTableBodyRows) {
				rowNumber++;
				// logger.info("Inner Html ==\n"+ webElement.getAttribute("innerHTML"));
				String innerHTML = webElement.getAttribute("innerHTML");
				if(innerHTML.indexOf(orderNumber)>0) {
					isOrderFound = true;
					logger.info(orderNumber+" is found at the row :"+rowNumber);
					break;
				}
			
			}
			rowNumber = isOrderFound ? rowNumber : 0;
			return rowNumber;
		}
		public static int getOrderNumberRowInWaiting4Pick(WebDriver driver, String orderNumber) {
			logger.info("------ORDER NUMBR------"+orderNumber);
			logger.info("------ORDER NUMBR length------"+orderNumber.length());
			orderNumber = orderNumber.trim();
			logger.info("------ORDER NUMBR length------"+orderNumber.length());
			WaitManager.applyJavaWait(5000);
			List<WebElement> unconfirmedOrderTableBodyRows = driver.findElements(By.xpath("//*[@id=\"waitingforpick\"]/div[2]/table/tbody/tr"));
		     int rowNumber = 0;
		     boolean isOrderFound = false;
		     logger.info("unconfirmedOrderTableBodyRows===="+(null !=unconfirmedOrderTableBodyRows?unconfirmedOrderTableBodyRows.size(): 0));
			for (WebElement webElement : unconfirmedOrderTableBodyRows) {
				rowNumber++;
				// logger.info("Inner Html ==\n"+ webElement.getAttribute("innerHTML"));
				String innerHTML = webElement.getAttribute("innerHTML");
				if(innerHTML.indexOf(orderNumber)>0) {
					isOrderFound = true;
					logger.info(orderNumber+" is found at the row :"+rowNumber);
					break;
				}
			
			}
			rowNumber = isOrderFound ? rowNumber : 0;
			return rowNumber;
		}
		
		public static int getOrderNumberRowInDeliveryInProgress(WebDriver driver, String orderNumber) {
			logger.info("------ORDER NUMBR------"+orderNumber);
			logger.info("------ORDER NUMBR length------"+orderNumber.length());
			orderNumber = orderNumber.trim();
			logger.info("------ORDER NUMBR length------"+orderNumber.length());
			WaitManager.applyJavaWait(5000);
			List<WebElement> unconfirmedOrderTableBodyRows = driver.findElements(By.xpath("//*[@id=\"ondelivery\"]/div[1]/table/tbody/tr"));
		     int rowNumber = 0;
		     boolean isOrderFound = false;
		     logger.info("unconfirmedOrderTableBodyRows===="+(null !=unconfirmedOrderTableBodyRows?unconfirmedOrderTableBodyRows.size(): 0));
			for (WebElement webElement : unconfirmedOrderTableBodyRows) {
				rowNumber++;
				// logger.info("Inner Html ==\n"+ webElement.getAttribute("innerHTML"));
				String innerHTML = webElement.getAttribute("innerHTML");
				if(innerHTML.indexOf(orderNumber)>0) {
					isOrderFound = true;
					logger.info(orderNumber+" is found at the row :"+rowNumber);
					break;
				}
			
			}
			rowNumber = isOrderFound ? rowNumber : 0;
			return rowNumber;
		}
		
		public static void dismissAllRejectedAlerts(WebDriver driver) {
			while(!isClickable(driver)) {
				try {
				WaitManager.applyJavaWait(2000);
				driver.switchTo().alert().accept();
				}catch(Exception e) {
					
				}
			}
		}
		
		public static boolean isClickable(WebDriver driver)      
		{
		try
		{
			WebElement webe = driver.findElement(By.cssSelector(".weborders.index"));
		
		   WebDriverWait wait = new WebDriverWait(driver, 5);
		   wait.until(ExpectedConditions.elementToBeClickable(webe));
		   return true;
		}
		catch (Exception e)
		{
			return false;
		}
		
	}
		public static void doAdminLogout(WebDriver driver)  {
			WaitManager.applyJavaWait(3000);
		//	WebElementManager.clickByJSExecutor(driver.findElement(By.cssSelector(".dropdown.pdaUP")), driver);
			WebElement logoutIcon=driver.findElement(By.xpath("//*[@id=\"topMenuBar\"]/div/div/div/ul[3]/li[2]/a/i"));
			WaitManager.applyJavaWait(4000);
			logoutIcon.click();
			
			WaitManager.applyJavaWait(3000);
			//WebElementManager.clickByJSExecutor(driver.findElement(By.xpath("//*[@id=\"topMenuBar\"]/div/div/div/ul[2]/div/ul/li[12]/a")), driver);
			WebElement logoutButton=driver.findElement(By.xpath("//*[@id=\"topMenuBar\"]/div/div/div/ul[3]/li[2]/ul")).findElement(By.partialLinkText("Log out"));
			WaitManager.applyJavaWait(3000);
			logoutButton.click();
		}
		
		
		
		
	}


