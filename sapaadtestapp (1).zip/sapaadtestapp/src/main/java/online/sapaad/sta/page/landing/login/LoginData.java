package online.sapaad.sta.page.landing.login;

public class LoginData {
	
	private String userName;
	private String password;
	private String loginType; // email or mobile
	private String expectedEmail;
	private String testType;
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getLoginType() {
		return loginType;
	}
	public void setLoginType(String loginType) {
		this.loginType = loginType;
	}
	public String getExpectedEmail() {
		return expectedEmail;
	}
	public void setExpectedEmail(String expectedEmail) {
		this.expectedEmail = expectedEmail;
	}
	public String getTestType() {
		return testType;
	}
	public void setTestType(String testType) {
		this.testType = testType;
	}
	
	public LoginData() {
	}
	public LoginData(String userName, String password, String loginType, String expectedEmail, String testType) {
		this.userName = userName;
		this.password = password;
		this.loginType = loginType;
		this.expectedEmail = expectedEmail;
		this.testType = testType;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((expectedEmail == null) ? 0 : expectedEmail.hashCode());
		result = prime * result + ((loginType == null) ? 0 : loginType.hashCode());
		result = prime * result + ((password == null) ? 0 : password.hashCode());
		result = prime * result + ((testType == null) ? 0 : testType.hashCode());
		result = prime * result + ((userName == null) ? 0 : userName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LoginData other = (LoginData) obj;
		if (expectedEmail == null) {
			if (other.expectedEmail != null)
				return false;
		} else if (!expectedEmail.equals(other.expectedEmail))
			return false;
		if (loginType == null) {
			if (other.loginType != null)
				return false;
		} else if (!loginType.equals(other.loginType))
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		if (testType == null) {
			if (other.testType != null)
				return false;
		} else if (!testType.equals(other.testType))
			return false;
		if (userName == null) {
			if (other.userName != null)
				return false;
		} else if (!userName.equals(other.userName))
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return "LoginData [userName=" + userName + ", password=" + password + ", loginType=" + loginType
				+ ", expectedEmail=" + expectedEmail + ", testType=" + testType + "]";
	}
	
	

}
