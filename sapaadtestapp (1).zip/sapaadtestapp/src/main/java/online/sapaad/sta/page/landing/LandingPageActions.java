package online.sapaad.sta.page.landing;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import online.sapaad.sta.driver.WaitManager;
import online.sapaad.sta.driver.WebElementConstants;
import online.sapaad.sta.driver.WebElementManager;
import online.sapaad.sta.page.landing.login.LoginData;
import online.sapaad.sta.page.landing.order.OrderItemData;
import online.sapaad.sta.page.landing.registration.RegistrationData;
import online.sapaad.sta.page.landing.registration.RegistrationFieldsPOM;
import online.sapaad.sta.page.landing.registration.RegistrationOTPFieldsPOM;

public class LandingPageActions {
	public final static Logger logger = Logger.getLogger(LandingPageActions.class);

	public static void inputUsername(WebDriver driver, String userName) {
		try {
			LandingPagePOM lpPom = new LandingPagePOM(driver);
			
			lpPom.getSignInOrRegisterBtn().click();
			WaitManager.applyJavaWait(3000);
			logger.info("userName==="+userName);
			lpPom.getEmailOrMobileTxtF().sendKeys(userName);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	public static void inputUsernameAndContinue(WebDriver driver, String userName) {
		try {
			// Thread.sleep(6000);
			// LandingPagePOM lpPom = new LandingPagePOM(driver);
			// Thread.sleep(6000);
//			WaitManager.applyJavaWait(3000);
//			WebElement loginSectiondiv =  driver.findElement(By.xpath("//div[@class=\"login_section\"]"));
			WebElement loginSectiondiv = WebElementManager.getElementByXpathAfterFWait(driver, 10000, 1000, "//div[@class=\"login_section\"]");
            loginSectiondiv.findElement(By.partialLinkText("Sign In")).click();
            // WaitManager.applyJavaWait(3000);
			// lpPom.getSignInOrRegisterBtn().click();
            //driver.findElement(By.id("phone")).sendKeys(userName);
            WebElementManager.getElementByIdAfterFWait(driver, 10000, 1000, "phone").sendKeys(userName);
			// lpPom.getEmailOrMobileTxtF().sendKeys(userName);
		//	lpPom = new LandingPagePOM(driver, true);
			// Thread.sleep(3000);
           // WaitManager.applyJavaWait(1000);
           // driver 
			//.findElement(By.xpath(LandingPageConstants.LOGIN_XPATH_SIGN_IN_CONTINUE_BTN)).click();
			//lpPom.getSignInContinueBtn().click();
			//WaitManager.applyJavaWait(1000);
			WebElementManager.getElementByXpathAfterFWait(driver, 10000, 1000, LandingPageConstants.LOGIN_XPATH_SIGN_IN_CONTINUE_BTN).click();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static void verifyEmailidIsDisplayed(WebDriver driver, LoginData data) {
		try {
			LandingPagePOM lpPom = new LandingPagePOM(driver, true);
			lpPom.getSignInContinueBtn().click();
			if (data.getTestType().equals("USER FOUND")) {

				WaitManager.applyJavaWait(1000);
				lpPom = new LandingPagePOM(driver, true);
				WebElement emailIdEle = lpPom.getEmailIdDisplayed();
				String actualEmail = emailIdEle.getAttribute(WebElementConstants.ATTRIBUTE_INNER_HTML);
				String expectedEmail = data.getExpectedEmail();
				assertEquals(actualEmail, expectedEmail);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static void verifyInvalidLogin(WebDriver driver, LoginData data) {
		try {
			if (null != data.getLoginType() && data.getLoginType().equals("INVALID")) {
				LandingPagePOM lpPom = new LandingPagePOM(driver, true);
				WebElement ele = lpPom.getSignPageHeader();
				String actualValue = ele.getAttribute(WebElementConstants.ATTRIBUTE_INNER_HTML);
				String expectedValue = "Sign in to your account.";
				assertEquals(actualValue, expectedValue);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static void doLoginForValidCredentials(WebDriver driver, LoginData data) {
		logger.info("Login Type =="+data.getLoginType());
		if (null != data.getLoginType() && !data.getLoginType().equals("INVALID")) {
			try {
			LandingPagePOM lpPom = new LandingPagePOM(driver, true);
			lpPom.getPasswordField().sendKeys(data.getPassword());
			lpPom.getSignInBtn().click();
			}catch(Exception e) {
				
			}
		}
	}

	public static void validateLoginTestCase(WebDriver driver, LoginData data) {
		if (data.getTestType().equals("USER FOUND")) {
			WaitManager.applyJavaWait(5000);
			LandingPagePOM lpPom = new LandingPagePOM(true, driver);
			WebElement userDisplayLink = lpPom.getUserDisplayLink();
			if (null != userDisplayLink) {
				userDisplayLink.click();
				WaitManager.applyJavaWait(2000);
				lpPom = new LandingPagePOM(true, driver);
				lpPom.getSignoutBtn().click();
				assertTrue(true, "Login Test successful for valid credentials");
			} else {
				assertFalse(true, "Login Test failed for invalid credentials");

			}

		} else {
			assertTrue(true, "Login Test successful for invalid credentials");

		}
	}
	public static void doLogin(WebDriver driver) {
		try {
			WaitManager.applyJavaWait(2000);
			LandingPagePOM lpPom = new LandingPagePOM(driver);
			lpPom.getSignInOrRegisterBtn().click();
			
			lpPom.getEmailOrMobileTxtF().sendKeys("7356712895");
			WaitManager.applyJavaWait(3000);
			 lpPom = new LandingPagePOM(driver, true);
			lpPom.getSignInContinueBtn().click();
			WaitManager.applyJavaWait(2000);
		    lpPom = new LandingPagePOM(driver, true);
			lpPom.getPasswordField().sendKeys("9446389911");
			lpPom.getSignInBtn().click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void inputRegistrationDataAndSubmit(WebDriver driver, RegistrationData data) throws InterruptedException {
		logger.info(data);
		if("VALID_SIGN_UP".equals(data.getCaseType())) {
		
			logger.info("Entered into valid signUp");
			inputAllRegistrationData(driver,data);
		}
		
		
	}
	public static void inputAllRegistrationData(WebDriver driver, RegistrationData data) throws InterruptedException {
		RegistrationFieldsPOM rfPom = new RegistrationFieldsPOM(driver);
		if("FROM_ORDER_FLOW".equals(data.getCaseSubType()) )  {
			// WaitManager.applyJavaWait(1000);
			WebElementManager.getElementByCssSelectorAfterFWait(driver, 10000, 1000, "#phone").sendKeys(LandingPageUtil.createDynamicMobileNumber());
			rfPom.getPhone().sendKeys(LandingPageUtil.createDynamicMobileNumber());
			// Thread.sleep(2000);
		}else {
			// WaitManager.applyJavaWait(1000);
			WebElementManager.getElementByCssSelectorAfterFWait(driver, 10000, 1000, "#Email").sendKeys(LandingPageUtil.createNewMailId(data.getEmailid()));
//			rfPom.getEmail().sendKeys(LandingPageUtil.createNewMailId(data.getEmailid()));
//			Thread.sleep(2000);
		}
		WebElementManager.getElementByCssSelectorAfterFWait(driver, 10000, 1000, "#fname").sendKeys(data.getFullName());
		// rfPom.getFirstName().sendKeys(data.getFullName());
		WebElementManager.getElementByCssSelectorAfterFWait(driver, 10000, 1000, "#password").sendKeys(data.getPassword());
		// rfPom.getPassword().sendKeys(data.getPassword());
		// rfPom.getConfirmPassword().sendKeys(data.getConfirmpassword());
		WebElementManager.getElementByCssSelectorAfterFWait(driver, 10000, 1000, "#confirmpassword").sendKeys(data.getConfirmpassword());
		// rfPom.getSignUpBtn().click();
		WebElementManager.getElementByCssSelectorAfterFWait(driver, 10000, 1000, "#header > div > div > div.popup-overlay > div > div > form > input").click();
		// WaitManager.applyJavaWait(2000);
	}
	public static void enterOtp(WebDriver driver, RegistrationData data) {
		if("VALID_SIGN_UP".equals(data.getCaseType())) {
			// RegistrationOTPFieldsPOM regOtpPom = new RegistrationOTPFieldsPOM(driver);
			
			WebElementManager.getElementByCssSelectorAfterFWait(driver, 10000, 1000, "#otp_1").sendKeys("1");
			WebElementManager.getElementByCssSelectorAfterFWait(driver, 10000, 1000, "#otp_2").sendKeys("2");
			WebElementManager.getElementByCssSelectorAfterFWait(driver, 10000, 1000, "#otp_3").sendKeys("3");
			WebElementManager.getElementByCssSelectorAfterFWait(driver, 10000, 1000, "#otp_4").sendKeys("4");
			// WaitManager.applyJavaWait(2000);
			WebElementManager.getElementByCssSelectorAfterFWait(driver, 10000, 1000, "#confirm_continue").click();
			if(!"FROM_ORDER_FLOW".equals(data.getCaseSubType())){
				verifyRegistration(driver);
			}
			
		}
	}
	public static void verifyRegistration(WebDriver driver) {
		// WaitManager.applyJavaWait(1000);
		if(null != WebElementManager.getElementByCssSelectorAfterFWait(driver, 10000, 1000, "#login_sec")) {
			assertTrue(true, "Successful Registrion Test: passed");
			WebElementManager.getElementByCssSelectorAfterFWait(driver, 10000, 1000, "#login_sec").click();
		//	WaitManager.applyJavaWait(1000);
			/*LandingPagePOM lpPom = new LandingPagePOM(0, driver);
			lpPom.getSignoutBtn().click();*/
			WebElementManager.getElementByXpathAfterFWait(driver, 10000, 1000, LandingPageConstants.SIGNOUT_XPATH_BTN).click();
		}else {
			assertTrue(false, "Successful Registrion Test: failed");
		}
	}
	public static void doLogout(WebDriver driver) {
		WebElement loginSectiondiv = WebElementManager.getElementByIdAfterFWait(driver, 10000, 1000, "login_sec");
		//driver.findElement(By.id("login_sec")).click();
		loginSectiondiv.click();
		/*
		LandingPagePOM lpPom = new LandingPagePOM(0, driver);
		 WaitManager.applyJavaWait(3000); */
		
		// WebElement element = lpPom.getSignoutBtn();
		WebElement element = WebElementManager.getElementByXpathAfterFWait(driver, 10000, 1000, LandingPageConstants.SIGNOUT_XPATH_BTN);
		Actions action = new Actions(driver); 
		action.moveToElement(element).click().build().perform();
		// lpPom.getSignoutBtn().click();
	
		
	}
	
	

}
