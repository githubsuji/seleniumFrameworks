package online.sapaad.sta.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Row.MissingCellPolicy;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import online.sapaad.sta.page.landing.login.LoginData;
import online.sapaad.sta.page.landing.order.OrderItemData;
import online.sapaad.sta.page.landing.registration.RegistrationData;
import online.sapaad.sta.payment.PaymentData;

public class ExcelUtil {
	public static InputStream getExcelTemplateStream(String filePath) {
		InputStream is = null;
		
		try {
			is = new FileInputStream(new File(filePath));
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return is;
	}
	public static List<LoginData> parseLoginDataExcel(InputStream excelIStream)
			throws IOException, EncryptedDocumentException, InvalidFormatException {

		Workbook workbook = WorkbookFactory.create(excelIStream);
        workbook.setMissingCellPolicy(MissingCellPolicy.RETURN_BLANK_AS_NULL);
        Sheet sheet = workbook.getSheetAt(0);//array of rows
        DataFormatter df = new DataFormatter();
        List<LoginData> list = new ArrayList<LoginData>();
        LoginData loginData = null;
        for (Row row : sheet) {
        	loginData = new LoginData();
        	for (int columnNumber = 0; columnNumber < row.getLastCellNum(); columnNumber++) {
				Cell cell = row.getCell(columnNumber);
				String cellValue = df.formatCellValue(cell);
				//int columnIndex  = cell.getColumnIndex();
				switch(columnNumber) {
				case 0:
					System.out.println(""+cellValue);
					loginData.setUserName(cellValue);
					break;
				case 1:
					System.out.println(""+cellValue);
					loginData.setPassword(cellValue);
					break;
				case 2:
					System.out.println(""+cellValue);
					loginData.setLoginType(cellValue);
					break;
				case 3:
					System.out.println(""+cellValue);
					loginData.setExpectedEmail(cellValue);
					break;	
				case 4:
					System.out.println(""+cellValue);
					loginData.setTestType(cellValue);
					break;
				default:
					break;
				}
			}//end of cell iteration
        	System.out.println("-----------ADDING THE" +loginData.toString()+" OBJECT-----------");
        	list.add(loginData);
		
        }// end of rows
       // workbook.close();
       // inputStream.close();
        System.out.println("-----------RETURNING THE QUESTION LIST-----------");
        return list;
        
	}
	
	public static List<RegistrationData> parseRegistrationDataExcel(InputStream excelIStream)
			throws IOException, EncryptedDocumentException, InvalidFormatException {

		Workbook workbook = WorkbookFactory.create(excelIStream);
        workbook.setMissingCellPolicy(MissingCellPolicy.RETURN_BLANK_AS_NULL);
        Sheet sheet = workbook.getSheetAt(0);//array of rows
        DataFormatter df = new DataFormatter();
        List<RegistrationData> list = new ArrayList<RegistrationData>();
        RegistrationData registrationData = null;
        for (Row row : sheet) {
        	registrationData = new RegistrationData();
        	for (int columnNumber = 0; columnNumber < row.getLastCellNum(); columnNumber++) {
				Cell cell = row.getCell(columnNumber);
				String cellValue = df.formatCellValue(cell);
				//int columnIndex  = cell.getColumnIndex();
				switch(columnNumber) {
				case 0:
					//System.out.println(""+cellValue);
					registrationData.setPhoneormobile(cellValue);
					break;
				case 1:
					//System.out.println(""+cellValue);
					registrationData.setEmailid(cellValue);
					break;
				case 2:
					//System.out.println(""+cellValue);
					registrationData.setFullName(cellValue);
					break;
				case 3:
				//	System.out.println(""+cellValue);
					registrationData.setPassword(cellValue);
					break;	
				case 4:
					//System.out.println(""+cellValue);
					registrationData.setConfirmpassword(cellValue);
					break;
				case 5:
				//	System.out.println("5  "+cellValue);
					registrationData.setCaseType(cellValue);
					break;
				case 6:
				//	System.out.println("6 "+cellValue);
					registrationData.setCaseSubType(cellValue);
					break;
				case 7:
				//	System.out.println("7 "+cellValue);
					registrationData.setExpectedResult(cellValue);
					break;
				default:
					break;
				}
			}//end of cell iteration
        	//System.out.println("-----------ADDING THE" +registrationData+" OBJECT-----------");
        	if(registrationData.getEmailid() != null && !registrationData.getEmailid().isEmpty()) {
        		list.add(registrationData);
        	}
        	
		
        }// end of rows
       // workbook.close();
       // inputStream.close();
        System.out.println("-----------RETURNING THE QUESTION LIST-----------");
        return list;
        
	}
	public static List<OrderItemData> parseOrderitemDataExcel(InputStream excelIStream) throws EncryptedDocumentException, InvalidFormatException, IOException {
		
		Workbook workbook = WorkbookFactory.create(excelIStream);
        workbook.setMissingCellPolicy(MissingCellPolicy.RETURN_BLANK_AS_NULL);
        Sheet sheet = workbook.getSheetAt(0);//array of rows
        DataFormatter df = new DataFormatter();
        List<OrderItemData> list = new ArrayList<OrderItemData>();
        OrderItemData orderItemData = null;
        RegistrationData rData = null;
        for (Row row : sheet) {
        	orderItemData = new OrderItemData();
        	rData = new RegistrationData();
        	for (int columnNumber = 0; columnNumber < row.getLastCellNum(); columnNumber++) {
				Cell cell = row.getCell(columnNumber);
				String cellValue = df.formatCellValue(cell);
				//int columnIndex  = cell.getColumnIndex();
				switch(columnNumber) {
				case 0:
					//System.out.println(""+cellValue);
					orderItemData.setUserName(cellValue);
					rData.setPhoneormobile(cellValue);
					break;
				case 1:
					//System.out.println(""+cellValue);
					orderItemData.setPassword(cellValue);
					rData.setPassword(cellValue);
					break;
				case 2:
					//System.out.println(""+cellValue);
					orderItemData.setLoginType(cellValue);
					break;
				case 3:
					//System.out.println(""+cellValue);
					orderItemData.setDeliveryLocation(cellValue);
					break;	
				case 4:
					//System.out.println(""+cellValue);
					orderItemData.setBuilding(cellValue);
					break;
				case 5:
					//System.out.println("5  "+cellValue);
					orderItemData.setStreet(cellValue);
					break;
				case 6:
					//System.out.println("6 "+cellValue);
					orderItemData.setFlatNumber(cellValue);
					break;
				case 7:
					//System.out.println("7 "+cellValue);
					orderItemData.setLandMark(cellValue);
					break;
				case 8:
				//	System.out.println("8 "+cellValue);
					orderItemData.setCardNumber(cellValue);
					break;
				case 9:
				//	System.out.println("9 "+cellValue);
					orderItemData.setExpiryDate(cellValue);
					break;	
				case 10:
					//System.out.println("10 "+cellValue);
					orderItemData.setCvv(cellValue);
					break;
				case 11:
					//System.out.println("11 "+cellValue);
					orderItemData.setExpiryMonth(cellValue);
					break;	
				case 12:
					//System.out.println("12 "+cellValue);
					orderItemData.setExpiryYear(cellValue);
					break;	
				case 13:
					//System.out.println("13 "+cellValue);
					rData.setConfirmpassword(cellValue);
					break;
				case 14:
				//	System.out.println("14 "+cellValue);
					rData.setFullName(cellValue);
					break;
				case 15:
					//System.out.println("15 "+cellValue);
					rData.setEmailid(cellValue);
					break;
				case 16:
				//	System.out.println("16 "+cellValue);
					rData.setPhoneormobile(cellValue);
					break;
				case 17:
					//System.out.println("17 "+cellValue);
					orderItemData.setDiscountCode(cellValue);
					break;
				case 18:
					//System.out.println("18 "+cellValue);
					orderItemData.setPaymentType(cellValue);
					break;
				case 19:
					//System.out.println("19 "+cellValue);
					orderItemData.setLoyality(cellValue);
					break;
				case 20:
					//System.out.println("20 "+cellValue);
					orderItemData.setDriver(cellValue);
					break;
				default:
					break;
				}
				
				
	        	if(columnNumber == 20 && orderItemData.getLoginType() != null &&
	        			!orderItemData.getLoginType().isEmpty()) {
	        		//System.out.println("-----------ADDING THE" +orderItemData+" OBJECT-----------");
	        		orderItemData.setRegistrationData(rData);
	        		list.add(orderItemData);
	        	}
			}//end of cell iteration
        	
        	
		
        }// end of rows
       // workbook.close();
       // inputStream.close();
        System.out.println("-----------RETURNING THE  LIST-----------");
        return list;
		
	}
public static List<PaymentData> parsePaymentDataExcel(InputStream excelIStream) throws EncryptedDocumentException, InvalidFormatException, IOException {
		
		Workbook workbook = WorkbookFactory.create(excelIStream);
        workbook.setMissingCellPolicy(MissingCellPolicy.RETURN_BLANK_AS_NULL);
        Sheet sheet = workbook.getSheetAt(0);//array of rows
        DataFormatter df = new DataFormatter();
        List<PaymentData> list = new ArrayList<PaymentData>();
        PaymentData paymentData = null;
        RegistrationData rData = null;
        for (Row row : sheet) {
        	paymentData = new PaymentData();
        	rData = new RegistrationData();
        	for (int columnNumber = 0; columnNumber < row.getLastCellNum(); columnNumber++) {
				Cell cell = row.getCell(columnNumber);
				String cellValue = df.formatCellValue(cell);
				//int columnIndex  = cell.getColumnIndex();
				switch(columnNumber) {
				case 0:
					//System.out.println(""+cellValue);
					paymentData.setUserName(cellValue);
					rData.setPhoneormobile(cellValue);
					break;
				case 1:
					//System.out.println(""+cellValue);
					paymentData.setPassword(cellValue);
					rData.setPassword(cellValue);
					break;
				case 2:
					//System.out.println(""+cellValue);
					paymentData.setLoginType(cellValue);
					break;
				case 3:
					//System.out.println(""+cellValue);
					paymentData.setDeliveryLocation(cellValue);
					break;	
				case 4:
					//System.out.println(""+cellValue);
					paymentData.setBuilding(cellValue);
					break;
				case 5:
					//System.out.println("5  "+cellValue);
					paymentData.setStreet(cellValue);
					break;
				case 6:
					//System.out.println("6 "+cellValue);
					paymentData.setFlatNumber(cellValue);
					break;
				case 7:
					//System.out.println("7 "+cellValue);
					paymentData.setLandMark(cellValue);
					break;
				case 8:
				//	System.out.println("8 "+cellValue);
					paymentData.setCardNumber(cellValue);
					break;
				case 9:
				//	System.out.println("9 "+cellValue);
					paymentData.setExpiryDate(cellValue);
					break;	
				case 10:
					//System.out.println("10 "+cellValue);
					paymentData.setCvv(cellValue);
					break;
				case 11:
					//System.out.println("11 "+cellValue);
					paymentData.setExpiryMonth(cellValue);
					break;	
				case 12:
					//System.out.println("12 "+cellValue);
					paymentData.setExpiryYear(cellValue);
					break;	
				case 13:
					//System.out.println("13 "+cellValue);
					rData.setConfirmpassword(cellValue);
					break;
				case 14:
				//	System.out.println("14 "+cellValue);
					rData.setFullName(cellValue);
					break;
				case 15:
					//System.out.println("15 "+cellValue);
					rData.setEmailid(cellValue);
					break;
				case 16:
				//	System.out.println("16 "+cellValue);
					rData.setPhoneormobile(cellValue);
					break;
				case 17:
					//System.out.println("17 "+cellValue);
					paymentData.setDiscountCode(cellValue);
					break;
				case 18:
					//System.out.println("18 "+cellValue);
					paymentData.setPaymentType(cellValue);
					break;
				case 19:
					//System.out.println("19 "+cellValue);
					paymentData.setLoyality(cellValue);
					break;
				
			
				default:
					break;
				}
				
				
	        	if(columnNumber == 19 && paymentData.getLoginType() != null &&
	        			!paymentData.getLoginType().isEmpty()) {
	        		//System.out.println("-----------ADDING THE" +orderItemData+" OBJECT-----------");
	        	
	        		list.add(paymentData);
	        	}
			}//end of cell iteration
        	
        	
		
        }// end of rows
       // workbook.close();
       // inputStream.close();
        System.out.println("-----------RETURNING THE  LIST-----------");
        return list;
		
	}
	/* test purpose */
	public static void main(String[] args) {
//		InputStream excel = getExcelTemplateStream("C:\\Users\\admin\\workspace\\sapaadtestapp\\src\\test\\resources\\data\\logindata.xlsx");
//		try {
//			List<LoginData> list= parseLoginDataExcel(excel);
//			System.err.println(list.size());
//		} catch (EncryptedDocumentException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (InvalidFormatException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		InputStream excel1 = getExcelTemplateStream("/Users/gayathri.r.nair/Downloads/sapaadtestapp/src/test/resources/data/OrderItemData.xlsx");
		try {
		List<OrderItemData> list= parseOrderitemDataExcel(excel1);
		for (OrderItemData orderItemData : list) {
			System.out.println(orderItemData);
		}
		System.err.println(list.size());
	} catch (EncryptedDocumentException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	} catch (InvalidFormatException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	} catch (IOException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
		InputStream excel2 = getExcelTemplateStream("/Users/gayathri.r.nair/Downloads/sapaadtestapp/src/test/resources/data/PaymentData.xlsx");
		try {
		List<PaymentData> list= parsePaymentDataExcel(excel2);
		for (PaymentData paymentData : list) {
			System.out.println(paymentData);
		}
		System.err.println(list.size());
	} catch (EncryptedDocumentException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	} catch (InvalidFormatException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	} catch (IOException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	}
	


}
