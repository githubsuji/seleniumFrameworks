package online.sapaad.sta.page.landing;

import java.util.Date;

import org.apache.log4j.Logger;

public class LandingPageUtil {
	public final static Logger logger = Logger.getLogger(LandingPageUtil.class);

	public static String createNewMailId(String mailId) {

		StringBuilder str = new StringBuilder(mailId);
		System.out.println("string = " + str);
		Date today = new Date(); // Fri Jun 17 14:54:28 PDT 2016
		// insert character at offset 8
		str.insert(mailId.indexOf('@'), today.getTime());
		String newMailId = str.toString();
		logger.info("Created Email Id: " + newMailId);
		return newMailId;
	}
	
	public static String createDynamicMobileNumber() {
		Date today = new Date(); 
		return String.valueOf(today.getTime());
	}

}
