package online.sapaad.sta.page.landing;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import online.sapaad.sta.driver.BaseTest;

public class LoginTest extends BaseTest {
	
	
	@BeforeMethod
	public void afterEachTestCase() {
		driver.get("https://www.facebook.com/");
	}
	
	@Test(description="Login test", dataProvider="loginDataProvider", dataProviderClass=LandinpageDataProvider.class)
	public void loginTest(LoginData data) {		
		System.err.println(data);
		
	}

}
