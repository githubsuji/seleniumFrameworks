package online.sapaad.sta.driver;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import static online.sapaad.sta.driver.DriverConstants.*;

import java.util.Arrays;
import java.util.concurrent.TimeUnit;

import io.github.bonigarcia.wdm.WebDriverManager;
public class BaseTest {
	
	protected WebDriver driver;

	
	@BeforeTest
	@Parameters({"browser"})
	public static void setupTest(String browser) {
		System.err.println("################"+browser);
		switch (browser) {
		case CHROME:
			System.err.println("######################");
			WebDriverManager.chromedriver().setup();
			break;
		case FIREFOX:
			WebDriverManager.firefoxdriver().setup();
			break;
		case EDGE:
			WebDriverManager.edgedriver().setup();
			break;
		case IE:
			WebDriverManager.iedriver().setup();
			break;
		case SAFARI:
			
			break;
		default:
			WebDriverManager.chromedriver().setup();
			break;
		}
		
	}
	
	@BeforeClass
	@Parameters({"browser"})
	public void setupClass(String browser) {
		switch (browser) {
		case CHROME:
			driver = DriverManager.getchromeDriver();
			break;
		case FIREFOX:
			driver = DriverManager.getGeckoDriver();
			break;
		case EDGE:
			driver = DriverManager.getEdgeDriver();
			break;
		case IE:
			driver = DriverManager.getIEDriver();
			break;			
		case SAFARI:
			break;
		default:
			driver = DriverManager.getchromeDriver();
			break;
		}
		driver.manage().timeouts().pageLoadTimeout(20000, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(20000, TimeUnit.SECONDS);
	}
	
	@AfterMethod
	public void afterEachTestCase() {
		
	}
	@AfterTest
	public void teardown() {
		if (driver != null) {
			driver.quit();
		}
	}
	
	
	

}
