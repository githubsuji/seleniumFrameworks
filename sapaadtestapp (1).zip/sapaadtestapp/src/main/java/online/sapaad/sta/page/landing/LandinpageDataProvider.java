package online.sapaad.sta.page.landing;

import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.annotations.DataProvider;

import online.sapaad.sta.page.landing.login.LoginData;
import online.sapaad.sta.page.landing.order.OrderItemData;
import online.sapaad.sta.page.landing.registration.RegistrationData;
import online.sapaad.sta.payment.PaymentData;
import online.sapaad.sta.util.ExcelUtil;

public class LandinpageDataProvider {
	
	@DataProvider(name="loginDataProvider")
	public static Iterator<LoginData> loginDataProvider() throws EncryptedDocumentException, InvalidFormatException, IOException{
		InputStream excel = ExcelUtil.getExcelTemplateStream("/Users/gayathri.r.nair/Downloads/sapaadtestapp/src/test/resources/data/logindata.xlsx");
		List<LoginData> list = ExcelUtil.parseLoginDataExcel(excel);
		list.remove(0);
		 // slist=list.subList(4,5);
		return list.iterator();
		
	}
	
	@DataProvider(name="registrationDataProvider")
	public static Iterator<RegistrationData> registrationDataProvider() throws EncryptedDocumentException, InvalidFormatException, IOException{
		InputStream excel = ExcelUtil.getExcelTemplateStream("/Users/gayathri.r.nair/Downloads/sapaadtestapp/src/test/resources/registration.xlsx");
		List<RegistrationData> list = ExcelUtil.parseRegistrationDataExcel(excel);
		list.remove(0);
		return list.iterator();
		
	}

	@DataProvider(name="orderItemDataProvider", parallel=false)
	public static Iterator<OrderItemData> orderItemDataProvider() throws EncryptedDocumentException, InvalidFormatException, IOException{
		InputStream excel = ExcelUtil.getExcelTemplateStream("/Users/gayathri.r.nair/Downloads/sapaadtestapp/src/test/resources/data/OrderItemData.xlsx");
		List<OrderItemData> list = ExcelUtil.parseOrderitemDataExcel(excel);
		 list.remove(0);
		// list=list.subList(1,2);
	   //list=list.subList(3,4);
		return list.iterator();
		
	}
	@DataProvider(name="PaymentDataProvider", parallel=false)
	public static Iterator<PaymentData> paymentDataProvider() throws EncryptedDocumentException, InvalidFormatException, IOException{
		InputStream excel = ExcelUtil.getExcelTemplateStream("/Users/gayathri.r.nair/Downloads/sapaadtestapp/src/test/resources/data/PaymentData.xlsx");
		List<PaymentData> list = ExcelUtil.parsePaymentDataExcel(excel);
       // list.remove(0);
		 // list=list.subList(1,10);
		 list=list.subList(1,4);
		return list.iterator();
		
	}
}
