package online.sapaad.sta.page.landing;
import java.util.Date;

import org.apache.log4j.Logger;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import online.sapaad.sta.driver.BaseTest;
import online.sapaad.sta.driver.WaitManager;
import online.sapaad.sta.page.landing.login.LoginData;
import online.sapaad.sta.page.landing.order.OrderItemData;
import online.sapaad.sta.payment.PaymentData;
public class PaymentTest extends BaseTest {
	public final static Logger logger = Logger.getLogger(PaymentTest.class);
	public long testCaseCount = 0;
	@BeforeMethod
	public void beforeEachTestCase() {
		logger.error("started");
		WaitManager.applyJavaWait(2000);
		driver.get("http://43c0253d18b042a193f5784ca3382c52.sapaad-review.online/");

	}
	@Test(dataProvider = "PaymentDataProvider", dataProviderClass = LandinpageDataProvider.class)
	public void PaymentTest(PaymentData ptdata) throws InterruptedException {

	startTime = new Date().getTime();
	logger.error("flowBaseOrderTest Test case begins....."+ new Date().getTime());
	logger.error("Order Test - Test Cae Number : "+ (++testCaseCount));
	logger.error("Order Test - Test Cae Number : /n "+ (ptdata));
	if (ptdata.getLoginType().equalsIgnoreCase("EXISTING-USER")) {
		paymentActions.doLogin(driver, ptdata);
	} else if (ptdata.getLoginType().equalsIgnoreCase("NEW-USER")) {
		logger.error(ptdata);
		logger.error(ptdata.getRegistrationData());
		ptdata.getRegistrationData().setCaseType("VALID_SIGN_UP");
		ptdata.getRegistrationData().setCaseSubType("FROM_ORDER_FLOW");
		LandingPageActions.inputUsernameAndContinue(driver,
		LandingPageUtil.createNewMailId(ptdata.getRegistrationData().getEmailid()));
		LandingPageActions.inputRegistrationDataAndSubmit(driver, ptdata.getRegistrationData());
		LandingPageActions.enterOtp(driver, ptdata.getRegistrationData());
	}
	paymentActions.addItemsToCart(driver,ptdata);
	paymentActions.doCheckout(driver);
	if(ptdata.getDeliveryLocation()!=null && !ptdata.getDeliveryLocation().isEmpty()) {
		boolean isMatchedLocationFound = paymentActions.selectMatchedLocation(driver, ptdata);
		if(!isMatchedLocationFound)paymentActions.addNewAddress(driver, ptdata);
	}
	
	paymentActions.doPayment(driver, ptdata);
	paymentActions.closeThankYouWindow(driver);
	paymentActions.doLoginAdminPanel(driver);
	paymentActions.sapaadSettings(driver);
	paymentActions.sapaadSetup(driver);
	
}
}