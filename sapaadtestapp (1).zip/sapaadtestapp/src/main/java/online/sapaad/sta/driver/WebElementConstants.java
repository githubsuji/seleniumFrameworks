package online.sapaad.sta.driver;

public class WebElementConstants {
	public static final String ATTRIBUTE_INNER_HTML = "innerHTML";

}
