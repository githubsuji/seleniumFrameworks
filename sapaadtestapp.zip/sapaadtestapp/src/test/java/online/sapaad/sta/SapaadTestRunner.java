package online.sapaad.sta;

import java.util.ArrayList;
import java.util.List;

import org.testng.TestNG;

public class SapaadTestRunner {

	public static void main(String[] args) {
		List<String> list = new ArrayList<String>();
		list.add("C:\\Users\\admin\\workspace\\sapaadtestapp\\src\\test\\resources\\development-suite.xml");
		TestNG testRunner =  new TestNG();
		testRunner.setTestSuites(list);
		testRunner.run();

	}

}
