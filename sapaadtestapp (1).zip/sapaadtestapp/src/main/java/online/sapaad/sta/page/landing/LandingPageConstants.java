package online.sapaad.sta.page.landing;

public class LandingPageConstants {
	public static String LOGIN_XPATH_SIGN_IN_CONTINUE_BTN = "//*[@id=\"header\"]/div/div/div[2]/div/div/form/input";
	public static String LOGIN_XPATH_SIGN_IN_EMAIL_FIELD= "//*[@id=\"header\"]/div/div/div[2]/div/div/form/div[1]/span";
	public static String SIGNUP_XPATH_SIGNUP_HEADER = "//*[@id=\"header\"]/div/div/div[2]/div/div/strong";
	public static String LOGIN_CSS_SELECTOR_PASSWORD = "#password";
	public static String LOGIN_CSS_SELECTOR_LOGIN = "#header > div > div > div.popup-overlay > div > div > form > input";
	public static final String LOGIN_PARTIAL_LINK_TEXT_USER_DISPLAY = "gayathri";
	public static String SIGNOUT_XPATH_BTN = "//*[@id=\"sign_out\"]";
	
	
}
