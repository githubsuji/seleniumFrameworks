package online.sapaad.sta.page.landing;

import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.annotations.DataProvider;

import online.sapaad.sta.util.ExcelUtil;

public class LandinpageDataProvider {
	
	@DataProvider(name="loginDataProvider")
	public static Iterator<LoginData> loginDataProvider() throws EncryptedDocumentException, InvalidFormatException, IOException{
		InputStream excel = ExcelUtil.getExcelTemplateStream("C:\\Users\\admin\\workspace\\sapaadtestapp\\src\\test\\resources\\data\\logindata.xlsx");
		List<LoginData> list = ExcelUtil.parseLoginDataExcel(excel);
		list.remove(0);
		return list.iterator();
	}

}
