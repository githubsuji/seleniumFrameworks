package online.sapaad.sta.page.landing;

import org.apache.log4j.Logger;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Ignore;
import org.testng.annotations.Test;

import online.sapaad.sta.driver.BaseTest;
import online.sapaad.sta.driver.WaitManager;
import online.sapaad.sta.page.landing.login.LoginData;


public class LoginTest extends BaseTest {
	public final static Logger logger = Logger.getLogger(LoginTest.class);

	@BeforeMethod
	public void beforeEachTestCase() {
		WaitManager.applyJavaWait(2000);
		driver.get("http://43c0253d18b042a193f5784ca3382c52.sapaad-review.online/");

	}

	@Test(description = "Login test", dataProvider = "loginDataProvider", dataProviderClass = LandinpageDataProvider.class)
	public void loginTest(LoginData data) {
		logger.info(data);
		LandingPageActions.inputUsername(driver, data.getUserName());
		LandingPageActions.verifyEmailidIsDisplayed(driver, data);
		LandingPageActions.verifyInvalidLogin(driver, data);
		LandingPageActions.doLoginForValidCredentials(driver, data);
		LandingPageActions.validateLoginTestCase(driver, data);

	}

}
