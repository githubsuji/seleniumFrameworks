package online.sapaad.sta.page.landing;

import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import online.sapaad.sta.driver.BaseTest;
import online.sapaad.sta.driver.WaitManager;
import online.sapaad.sta.page.landing.order.OrderItemData;
import online.sapaad.sta.util.ExcelUtil;

public class OrderTest extends BaseTest {
	public final static Logger logger = Logger.getLogger(OrderTest.class);
	public long testCaseCount = 0;
	
	@BeforeMethod
	public void beforeEachTestCase() {
		logger.error("Test case begins.....");
		// WaitManager.applyJavaWait(3000);
		driver.get("http://43c0253d18b042a193f5784ca3382c52.sapaad-review.online/");
		WaitManager.applyJavaWait(8000);
		
	}
	
	@Test(dataProvider = "orderItemDataProvider", dataProviderClass = LandinpageDataProvider.class)
	public void flowBaseOrderTest(OrderItemData oidata) throws InterruptedException {
	//	driver.navigate().refresh();
	//	WaitManager.applyJavaWait(5000);
		startTime = new Date().getTime();
		logger.error("flowBaseOrderTest Test case begins....."+ new Date().getTime());
		logger.error("Order Test - Test Cae Number : "+ (++testCaseCount));
		logger.error("Order Test - Test Cae Number : /n "+ (oidata));
		if (oidata.getLoginType().equalsIgnoreCase("EXISTING-USER")) {
			OrderActions.doLogin(driver, oidata);
		} else if (oidata.getLoginType().equalsIgnoreCase("NEW-USER")) {
			logger.error(oidata);
			logger.error(oidata.getRegistrationData());
			oidata.getRegistrationData().setCaseType("VALID_SIGN_UP");
			oidata.getRegistrationData().setCaseSubType("FROM_ORDER_FLOW");
			LandingPageActions.inputUsernameAndContinue(driver,
			LandingPageUtil.createNewMailId(oidata.getRegistrationData().getEmailid()));
			LandingPageActions.inputRegistrationDataAndSubmit(driver, oidata.getRegistrationData());
			LandingPageActions.enterOtp(driver, oidata.getRegistrationData());
		}
		OrderActions.addItemsToCart(driver,oidata);
		OrderActions.doCheckout(driver);
		if(oidata.getDeliveryLocation()!=null && !oidata.getDeliveryLocation().isEmpty()) {
			boolean isMatchedLocationFound = OrderActions.selectMatchedLocation(driver, oidata);
			if(!isMatchedLocationFound)OrderActions.addNewAddress(driver, oidata);
		}
		
		OrderActions.doPayment(driver, oidata);
		OrderActions.closeThankYouWindow(driver);
		String OrderID = OrderActions.getOrderID(driver);
		logger.error("Order ID: "+OrderID);
		LandingPageActions.doLogout(driver);
		OrderActions.doLoginAdminPanel(driver);
		OrderActions.doOnlineMenuClick(driver);
		OrderActions.dismissAllRejectedAlerts(driver);
		logger.info("All Alerts removed");
		OrderActions.doOrderReviewByAdmin(driver, OrderID);
		OrderActions.doDeliveryManagerMenuClick(driver, OrderID,oidata);

		OrderActions.doAdminLogout(driver);
		
		
		

	}
	
	
	
	/*

	@DataProvider(name="orderItemDataProvider", parallel=false)
	public static Iterator<OrderItemData> orderItemDataProvider() throws EncryptedDocumentException, InvalidFormatException, IOException{
		InputStream excel = ExcelUtil.getExcelTemplateStream("/Users/gayathri.r.nair/Downloads/sapaadtestapp/src/test/resources/data/OrderItemData.xlsx");
		List<OrderItemData> list = ExcelUtil.parseOrderitemDataExcel(excel);
		// list.remove(0);
		 list=list.subList(1, 12);
		return list.iterator();
		
	}
	*/
	
}
