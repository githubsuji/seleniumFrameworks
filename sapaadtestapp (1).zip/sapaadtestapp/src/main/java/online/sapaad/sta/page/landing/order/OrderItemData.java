package online.sapaad.sta.page.landing.order;

import online.sapaad.sta.page.landing.registration.RegistrationData;

public class OrderItemData {
	private String userName;
	private String password;
	private String loginType; // email or mobile or new-user
	private String deliveryLocation;
	private String building;
	private String street;
	private String flatNumber;
	private String landMark;
	private String cardNumber;
	private String expiryDate; //2010 --> yearmonth
	private String cvv;
	private String expiryMonth; // February
	private String expiryYear; // 2020
	private String discountCode;
	private String paymentType;
	private String driver;
	private String loyality;
	private RegistrationData registrationData;
	
	public OrderItemData() {
	}

	public OrderItemData(String userName, String password, String loginType, String deliveryLocation, String building,
			String street, String flatNumber, String landMark, String cardNumber, String expiryDate, String cvv,
			String expiryMonth, String expiryYear, String discountCode, String paymentType, String driver,
			String loyality, RegistrationData registrationData) {
		this.userName = userName;
		this.password = password;
		this.loginType = loginType;
		this.deliveryLocation = deliveryLocation;
		this.building = building;
		this.street = street;
		this.flatNumber = flatNumber;
		this.landMark = landMark;
		this.cardNumber = cardNumber;
		this.expiryDate = expiryDate;
		this.cvv = cvv;
		this.expiryMonth = expiryMonth;
		this.expiryYear = expiryYear;
		this.discountCode = discountCode;
		this.paymentType = paymentType;
		this.driver = driver;
		this.loyality = loyality;
		this.registrationData = registrationData;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getLoginType() {
		return loginType;
	}

	public void setLoginType(String loginType) {
		this.loginType = loginType;
	}

	public String getDeliveryLocation() {
		return deliveryLocation;
	}

	public void setDeliveryLocation(String deliveryLocation) {
		this.deliveryLocation = deliveryLocation;
	}

	public String getBuilding() {
		return building;
	}

	public void setBuilding(String building) {
		this.building = building;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getFlatNumber() {
		return flatNumber;
	}

	public void setFlatNumber(String flatNumber) {
		this.flatNumber = flatNumber;
	}

	public String getLandMark() {
		return landMark;
	}

	public void setLandMark(String landMark) {
		this.landMark = landMark;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getCvv() {
		return cvv;
	}

	public void setCvv(String cvv) {
		this.cvv = cvv;
	}

	public String getExpiryMonth() {
		return expiryMonth;
	}

	public void setExpiryMonth(String expiryMonth) {
		this.expiryMonth = expiryMonth;
	}

	public String getExpiryYear() {
		return expiryYear;
	}

	public void setExpiryYear(String expiryYear) {
		this.expiryYear = expiryYear;
	}

	public String getDiscountCode() {
		return discountCode;
	}

	public void setDiscountCode(String discountCode) {
		this.discountCode = discountCode;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getDriver() {
		return driver;
	}

	public void setDriver(String driver) {
		this.driver = driver;
	}

	public String getLoyality() {
		return loyality;
	}

	public void setLoyality(String loyality) {
		this.loyality = loyality;
	}

	public RegistrationData getRegistrationData() {
		return registrationData;
	}

	public void setRegistrationData(RegistrationData registrationData) {
		this.registrationData = registrationData;
	}

	@Override
	public String toString() {
		return "OrderItemData [userName=" + userName + ", password=" + password + ", loginType=" + loginType
				+ ", deliveryLocation=" + deliveryLocation + ", building=" + building + ", street=" + street
				+ ", flatNumber=" + flatNumber + ", landMark=" + landMark + ", cardNumber=" + cardNumber
				+ ", expiryDate=" + expiryDate + ", cvv=" + cvv + ", expiryMonth=" + expiryMonth + ", expiryYear="
				+ expiryYear + ", discountCode=" + discountCode + ", paymentType=" + paymentType + ", driver=" + driver
				+ ", loyality=" + loyality + ", registrationData=" + registrationData + "]";
	}

	
	
	
	
	
	

}
