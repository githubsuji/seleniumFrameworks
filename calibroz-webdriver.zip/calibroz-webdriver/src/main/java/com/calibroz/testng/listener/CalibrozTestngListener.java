package com.calibroz.testng.listener;

public class CalibrozTestngListener extends TestCaseMethodListener {

}
